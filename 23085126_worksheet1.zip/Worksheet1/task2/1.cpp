#include <iostream>
using namespace std;

int main(){
    //declaring variables
int a;  //let a be the last value
int b;  //let b be the current value
int n;  //number


cout<<"Enter a positive integer number: ";
cin>>n;
a=n % 10;  //get last digit
n=n/10;  //removal of last digit

   //for tracking the increasing and decreasing digits
    int increasing = 0;
    int decreasing = 0;

    while (n>0) {
            b= n%10;     //get last digit
         if (b<a) increasing = 1;
         if (b>a) decreasing = 1;
        a=b;
       n=n/10;  //removal of last digit
    }

    if ( increasing==1 && decreasing==1){
        cout << "It is a bouncy number" << endl;
    }
    else {
            cout << "It is not a bouncy number" << endl;
    }

return 0;
}

