#include <iostream>
using namespace std;

const int SIZE = 5;
char seats[SIZE][SIZE] = {
    {'O', 'O', 'O', 'O', 'O'},
    {'O', 'O', 'O', 'O', 'O'},
    {'O', 'O', 'O', 'O', 'O'},
    {'O', 'O', 'O', 'O', 'O'},
    {'O', 'O', 'O', 'O', 'O'}
};

void displaybookedseats() {
    cout << " The current Seating Arrangement is: "<<endl;
    for (int i = 0; i < SIZE; i++) {
    for (int j = 0; j < SIZE; j++) {
        cout << seats[i][j] << " ";
    }
        cout << endl;
    }
    }

 int main() {
int rows, column;
char ch;
 while (true) {
        displaybookedseats();  // Seating arrangement

        // Ask user for input and validate
        cout << "Enter the rows in (1-5) and columns in (1-5) to book a seat for the cinema ticket: ";
        cin >> rows >> column;

        // Check if input is valid
        if (rows < 1 || rows > SIZE || column < 1 || column > SIZE) {
            cout << "Error!!!!! NO SEAT. TRY between (1-5)."<<endl;
        }
// Convert to 0-indexed
        rows--;
        column--;

 // to check seat is already booked or not
 if (seats[rows][column] == 'X') {
    cout << "Error!!!!! NO SEAT "<<endl;
        }
    else {
    seats[rows][column] = 'X';  // Booked seat
        cout << "Seat booked successfully! "<<endl;
        }

 // Asking the  user if they want to book other seat
        cout << "Do you want to book otherseat? (y/n): "<<endl;
        cin >> ch;
        if (ch=='n' || ch=='N') {
    break;
        }}

// Final display after booking is done
    cout << "Final Seating Arrangement: "<<endl;
    displaybookedseats();  // The final seating arrangement
 return 0;
}
