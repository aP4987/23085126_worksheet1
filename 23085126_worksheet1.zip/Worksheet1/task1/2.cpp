#include <iostream>
using namespace std;

int main() {
    int ch, targetnum, guessnum;    //choice, targetnumber, guessnumber

    cout << " Choose a number with different ranges\n";     //user choose
    cout << "1. Easy difficulty ranges from 1-8. "<<endl;
    cout << "2. Medium difficulty ranges from 1-30. "<<endl;
    cout << "3. Hard difficulty ranges from 1-50. "<<endl;
    cin >> ch;
    cout << "You choose: " << ch <<endl;

    // giving targeted number to the user to guess the number.
    if (ch == 1) {
            targetnum =4;
    }
    else if (ch ==2) {
            targetnum =27;
    }
    else if (ch==3) {
            targetnum =39;
    }
    else
    {
        cout << "Try again."<<endl;
    }
    // Guess the number
    do {
        cout << "Guess the number: \n";     //asking user
        cin >> guessnum;

    if (guessnum > targetnum) {
        cout << "Try lower."<<endl;
        }

    else if (guessnum < targetnum) {
        cout << "Try higher"<<endl;
        }

    else {
        cout << "Good job. That's the correct number!"<<endl;
        }
    }
    while (guessnum != targetnum);  // for guessing a correct number

return 0;
}
