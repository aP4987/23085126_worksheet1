#include <iostream>
using namespace std;

int main() {
    float ip, op;   // input and output temperatures
    int ch;     //  user's choice
    cout << "Enter the temperature: ";      //asking user
    cin >> ip;

// Asking user for choice
cout << "1. Celsius to Fahrenheit conversion" <<endl;
cout << "2. Fahrenheit to Celsius conversion" <<endl;
cin >> ch;
cout<<"You choose " << ch <<endl;

// Using switch-case
switch(ch) {
case 1:
 op = (ip*9.0/5.0)+32;     // Celsius to Fahrenheit
 cout <<"The conversion temperature " << ip << " is: "<< op << " F" <<endl;
break;

 case 2:
 op = (ip-32)*5.0/9.0;     // Fahrenheit to Celsius
 cout <<"The conversion temperature " << ip << " is: "<< op << " C" <<endl;
break;

default:
 cout << "Exit" << endl;
}

    return 0;
}
